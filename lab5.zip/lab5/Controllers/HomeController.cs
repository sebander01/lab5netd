﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using lab5.Models;
//Sebastian Anderson
//     December 4th, 2020
//    Lab Five
namespace lab5.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public double LateFees(LibraryCardOwner card, Book book)
        {
            double balanceTemp = 0;
            for (int i = 0; i < card.numberOfBooksOut; i++)
            {
                double Temp = 0;
                Temp = book.daysOut * book.originalPrice / book.conditionValue(book.borrowedCondition, book.condition);
                balanceTemp = balanceTemp + Temp;
            }
            card.balanceOwed = balanceTemp * card.numberOfBooksOut;
            return card.balanceOwed;

        }


    }
}
