﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using lab5.Models;
//Sebastian Anderson
//     December 4th, 2020
//    Lab Five
namespace lab5.Controllers
{
    public class LibraryCardOwnersController : Controller
    {
        private readonly BooksContext _context;

        public LibraryCardOwnersController(BooksContext context)
        {
            _context = context;
        }

        // GET: LibraryCardOwners
        public async Task<IActionResult> Index()
        {
            return View(await _context.Card.ToListAsync());
        }

        // GET: LibraryCardOwners/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var libraryCardOwner = await _context.Card
                .FirstOrDefaultAsync(m => m.Id == id);
            if (libraryCardOwner == null)
            {
                return NotFound();
            }

            return View(libraryCardOwner);
        }

        // GET: LibraryCardOwners/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: LibraryCardOwners/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,firstName,lastName,numberOfBooksOut,balanceOwed,dateInstated,dateExpiration,expireyDate,valid")] LibraryCardOwner libraryCardOwner)
        {
            if (ModelState.IsValid)
            {
                _context.Add(libraryCardOwner);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(libraryCardOwner);
        }

        // GET: LibraryCardOwners/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var libraryCardOwner = await _context.Card.FindAsync(id);
            if (libraryCardOwner == null)
            {
                return NotFound();
            }
            return View(libraryCardOwner);
        }

        // POST: LibraryCardOwners/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,firstName,lastName,numberOfBooksOut,balanceOwed,dateInstated,dateExpiration,expireyDate,valid")] LibraryCardOwner libraryCardOwner)
        {
            if (id != libraryCardOwner.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(libraryCardOwner);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LibraryCardOwnerExists(libraryCardOwner.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(libraryCardOwner);
        }

        // GET: LibraryCardOwners/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var libraryCardOwner = await _context.Card
                .FirstOrDefaultAsync(m => m.Id == id);
            if (libraryCardOwner == null)
            {
                return NotFound();
            }

            return View(libraryCardOwner);
        }

        // POST: LibraryCardOwners/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var libraryCardOwner = await _context.Card.FindAsync(id);
            _context.Card.Remove(libraryCardOwner);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LibraryCardOwnerExists(int id)
        {
            return _context.Card.Any(e => e.Id == id);
        }
    }
}
