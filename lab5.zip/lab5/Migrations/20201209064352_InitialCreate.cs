﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace lab5.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Books",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dateBorrowed = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    daysOut = table.Column<int>(type: "int", nullable: false),
                    originalPrice = table.Column<double>(type: "float", nullable: false),
                    borrowedCondition = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    condition = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Books", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Card",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    firstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    lastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    numberOfBooksOut = table.Column<int>(type: "int", nullable: false),
                    balanceOwed = table.Column<double>(type: "float", nullable: false),
                    dateInstated = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dateExpiration = table.Column<DateTime>(type: "datetime2", nullable: false),
                    expireyDate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    valid = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Card", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Books");

            migrationBuilder.DropTable(
                name: "Card");
        }
    }
}
