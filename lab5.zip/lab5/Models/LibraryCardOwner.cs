﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//Sebastian Anderson
//     December 4th, 2020
//    Lab Five
namespace lab5.Models
{
    public class LibraryCardOwner
    {
        public int Id { get; set; }
        public string firstName { get; set; }

        public string lastName { get; set; }

        public int numberOfBooksOut { get; set; }

        public double balanceOwed { get; set; }

        public string dateInstated { get; set; }

        public DateTime dateExpiration { get; set; }

        public string expireyDate { get; set; }

        public bool valid { get; set; }

        //Checks if the date is valid
        public bool isValid(DateTime dateExpiration, bool valid)
        {
            DateTime date = System.DateTime.Now.Date;
            if(dateExpiration <= date )
            {
                valid = true;
            }
            else if(dateExpiration > date)
            {
                valid = false;
            }
            return valid;
        }

        //Checks if your allowed to check out another book
        public bool bookCheckout(int numberOfBooksOut, bool valid)
        {
            //Only five books per person
            int maxBooks = 5;
            if(numberOfBooksOut <= maxBooks)
            {
                valid = true;
            }
            else
            {
                valid = false;
            }
            return valid;
        }

    }
}
