﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//Sebastian Anderson
//     December 4th, 2020
//    Lab Five
namespace lab5.Models
{
    public class Book
    {
        public int ID { get; set; }
        public string title { get; set; }

        public string dateBorrowed { get; set; }

        public int daysOut { get; set; }

        public double originalPrice { get; set; }

        public string borrowedCondition { get; set; }
        public string condition { get; set; }



        //Amount to divde by
        public int conditionValue(string borrowedCondition, string condition)
        {
            int value = 0;
            //If condition was new
            if (borrowedCondition == condition)
            {
                value = 5;
            }
            else if (borrowedCondition == "Damaged" && condition == "New")
            {
                value = 1;
            }
            else if (borrowedCondition == "Poor" && condition == "New")
            {
                value = 2;
            }
            else if (borrowedCondition == "Bad" && condition == "New")
            {
                value = 3;
            }
            else if (borrowedCondition == "Good" && condition == "New")
            {
                value = 4;
            }
            //If was in good condition
            else if (borrowedCondition == "Damaged" && condition == "Good")
            {
                value = 1;
            }
            else if (borrowedCondition == "Poor" && condition == "Good")
            {
                value = 2;
            }
            else if (borrowedCondition == "Bad" && condition == "New")
            {
                value = 3;
            }
            //If was in bad condition
            else if (borrowedCondition == "Damaged" && condition == "Bad")
            {
                value = 1;
            }
            else if (borrowedCondition == "Poor" && condition == "Bad")
            {
                value = 2;
            }
            //If was in poor condition
            else if (borrowedCondition == "Damaged" && condition == "Poor")
            {
                value = 1;
            }
            //Damged will always come back in damaged condtiion so it dosen't need anything besides the first if statment.
            return value;
        }
    }
}
