﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
//Sebastian Anderson
//     December 4th, 2020
//    Lab Five
namespace lab5.Models
{
    public class BooksContext : DbContext
    {
            public BooksContext(DbContextOptions<BooksContext> options) : base(options)
            {

            }

            public DbSet<Book> Books { get; set; }
            public DbSet<LibraryCardOwner> Card { get; set; }
    }
}
